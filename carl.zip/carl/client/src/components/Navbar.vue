<template>
    <div id="header"> <a href="#" id="logo"><img src="../assets/logo.gif" width="310" height="114" alt=""></a>
  <ul class="navigation">
    <li class="active"><a href="index.html">Home</a></li>
    <li><a href="#">PetMart</a></li>
    <li><a href="#">About us</a></li>
    <li><a href="#">Blog</a></li>
    <li><a href="#">PetGuide</a></li>
    <li><a href="#">Contact us</a></li>
  </ul>
</div>
</template>>