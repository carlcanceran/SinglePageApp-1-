module.exports = {
    mongoURI:"mongodb://localhost:27017/webapp_db",
    secret: "yoursecret"
}